import express from 'express';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { searchSongs, getSongLyrics } from './services/lyrics.js';
import { scrapeGeniusSong } from './services/genius.js';
import { cacheStats } from './cache.js';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.use(rateLimit({
  windowMs: config.rateLimitWindowMs,
  limit: config.rateLimitMax,
  standardHeaders: 'draft-7',
  legacyHeaders: false
}));

app.get('/', (_req, res) => {
  res.json({
    name: 'Genius Lyrics API',
    version: '1.0.0',
    endpoints: {
      search: '/search?q=artist%20song',
      lyrics: '/lyrics?title=Song&artist=Artist',
      scrape: 'POST /scrape { "url": "https://genius.com/..." }',
      health: '/health'
    }
  });
});

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', cache: cacheStats(), timestamp: new Date().toISOString() });
});

app.get('/search', async (req, res, next) => {
  try {
    const q = String(req.query.q || '').trim();
    if (!q) return res.status(400).json({ success: false, error: 'Query parameter q is required.' });
    if (q.length > 200) return res.status(400).json({ success: false, error: 'Search query is too long.' });
    res.json({ success: true, ...(await searchSongs(q)) });
  } catch (error) { next(error); }
});

app.get('/lyrics', async (req, res, next) => {
  try {
    const title = String(req.query.title || '').trim();
    const artist = String(req.query.artist || '').trim();
    if (!title || !artist) {
      return res.status(400).json({ success: false, error: 'Both title and artist query parameters are required.' });
    }
    const result = await getSongLyrics({
      title,
      artist,
      album: req.query.album ? String(req.query.album) : undefined,
      duration: req.query.duration ? Number(req.query.duration) : undefined,
      geniusUrl: req.query.genius_url ? String(req.query.genius_url) : undefined
    });
    res.status(result.success ? 200 : 404).json(result);
  } catch (error) { next(error); }
});

app.post('/scrape', async (req, res, next) => {
  try {
    const url = String(req.body?.url || '');
    if (!url) return res.status(400).json({ success: false, error: 'JSON body must include url.' });
    const result = await scrapeGeniusSong(url);
    res.json({ success: result.lyrics_found, song: result });
  } catch (error) { next(error); }
});

app.use((error, _req, res, _next) => {
  const status = error.response?.status === 429 ? 503 : 500;
  if (config.nodeEnv !== 'production') {
    console.error(error.message);
  }
  res.status(status).json({
    success: false,
    error: status === 503 ? 'Upstream service is rate limiting requests. Try again later.' : 'Request failed.',
    ...(config.nodeEnv !== 'production' ? { detail: error.message } : {})
  });
});

app.listen(config.port, () => {
  console.log(`Lyrics API listening on http://localhost:${config.port}`);
});
