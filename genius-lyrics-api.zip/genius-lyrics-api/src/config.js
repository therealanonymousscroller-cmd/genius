import 'dotenv/config';

const number = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
};

export const config = {
  port: number(process.env.PORT, 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  geniusToken: process.env.GENIUS_ACCESS_TOKEN || '',
  geniusScrapeEnabled: process.env.GENIUS_SCRAPE_ENABLED !== 'false',
  requestTimeoutMs: number(process.env.REQUEST_TIMEOUT_MS, 12000),
  cacheTtlSeconds: number(process.env.CACHE_TTL_SECONDS, 21600),
  maxSearchResults: Math.min(number(process.env.MAX_SEARCH_RESULTS, 10), 30),
  geniusSearchPageSize: Math.min(number(process.env.GENIUS_SEARCH_PAGE_SIZE, 10), 20),
  rateLimitWindowMs: number(process.env.RATE_LIMIT_WINDOW_MS, 60000),
  rateLimitMax: number(process.env.RATE_LIMIT_MAX, 60),
  proxy: {
    default: process.env.PROXY_URL || '',
    genius: process.env.GENIUS_PROXY_URL || '',
    lrclib: process.env.LRCLIB_PROXY_URL || ''
  }
};
