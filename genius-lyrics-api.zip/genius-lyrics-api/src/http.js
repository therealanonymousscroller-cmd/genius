import axios from 'axios';
import { HttpProxyAgent } from 'http-proxy-agent';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { SocksProxyAgent } from 'socks-proxy-agent';
import { config } from './config.js';

const agentCache = new Map();

function agentsFor(proxyUrl) {
  if (!proxyUrl) return {};
  if (agentCache.has(proxyUrl)) return agentCache.get(proxyUrl);

  let agents;
  if (/^socks[45]h?:\/\//i.test(proxyUrl)) {
    const agent = new SocksProxyAgent(proxyUrl);
    agents = { httpAgent: agent, httpsAgent: agent };
  } else if (/^https:\/\//i.test(proxyUrl)) {
    agents = {
      httpAgent: new HttpProxyAgent(proxyUrl),
      httpsAgent: new HttpsProxyAgent(proxyUrl)
    };
  } else if (/^http:\/\//i.test(proxyUrl)) {
    agents = {
      httpAgent: new HttpProxyAgent(proxyUrl),
      httpsAgent: new HttpsProxyAgent(proxyUrl)
    };
  } else {
    throw new Error('Unsupported proxy URL. Use HTTP(S) or SOCKS4/5.');
  }

  agentCache.set(proxyUrl, agents);
  return agents;
}

export function clientFor(provider = 'default') {
  const proxyUrl = config.proxy[provider] || config.proxy.default;
  const agents = agentsFor(proxyUrl);

  return axios.create({
    timeout: config.requestTimeoutMs,
    proxy: false,
    ...agents,
    headers: {
      'User-Agent': 'PersonalLyricsAPI/1.0 (+personal project)',
      'Accept': 'application/json, text/html;q=0.9, */*;q=0.8'
    },
    maxRedirects: 5
  });
}
