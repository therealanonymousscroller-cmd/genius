export function normalizeText(value = '') {
  return String(value).toLowerCase().normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

export function slugify(value = '') {
  return normalizeText(value).replace(/\s+/g, '-');
}

export function scoreMatch(a, b) {
  const left = normalizeText(a);
  const right = normalizeText(b);
  if (!left || !right) return 0;
  if (left === right) return 1;
  if (left.includes(right) || right.includes(left)) return 0.85;
  const A = new Set(left.split(' '));
  const B = new Set(right.split(' '));
  const intersection = [...A].filter(x => B.has(x)).length;
  return intersection / new Set([...A, ...B]).size;
}

export function parseLrcTimestamp(timestamp) {
  const match = timestamp.match(/^\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]$/);
  if (!match) return null;
  const fraction = Number(`0.${match[3] || '0'}`);
  return Number(match[1]) * 60 + Number(match[2]) + fraction;
}

export function parseLrc(lrc = '') {
  const lines = [];
  for (const rawLine of lrc.split(/\r?\n/)) {
    const matches = [...rawLine.matchAll(/\[(\d{1,2}:\d{2}(?:\.\d{1,3})?)\]/g)];
    const text = rawLine.replace(/(?:\[\d{1,2}:\d{2}(?:\.\d{1,3})?\])+/g, '').trim();
    for (const match of matches) {
      const time = parseLrcTimestamp(`[${match[1]}]`);
      if (time !== null && text) lines.push({ time, text });
    }
  }
  return lines.sort((a, b) => a.time - b.time);
}

export function normalizeWordSynced(rawLines) {
  if (!Array.isArray(rawLines)) return null;
  const words = [];
  for (const line of rawLines) {
    if (!Array.isArray(line.words)) continue;
    for (const word of line.words) {
      const text = word.word ?? word.text;
      const start = word.startTimeMs ?? word.start_time_ms ?? word.time;
      if (text != null && Number.isFinite(Number(start))) {
        words.push({ time: Number(start) / (Number(start) > 1000 ? 1000 : 1), text: String(text) });
      }
    }
  }
  return words.length ? words.sort((a, b) => a.time - b.time) : null;
}
