import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';

const dataDir = path.resolve('data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'cache.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS cache (
    cache_key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    expires_at INTEGER NOT NULL
  );
`);

const getStmt = db.prepare('SELECT value, expires_at FROM cache WHERE cache_key = ?');
const putStmt = db.prepare(`
  INSERT INTO cache(cache_key, value, expires_at) VALUES (?, ?, ?)
  ON CONFLICT(cache_key) DO UPDATE SET value=excluded.value, expires_at=excluded.expires_at
`);

export function cacheGet(key) {
  const row = getStmt.get(key);
  if (!row) return null;
  if (row.expires_at < Date.now()) {
    db.prepare('DELETE FROM cache WHERE cache_key = ?').run(key);
    return null;
  }
  try { return JSON.parse(row.value); } catch { return null; }
}

export function cacheSet(key, value, ttlSeconds) {
  putStmt.run(key, JSON.stringify(value), Date.now() + ttlSeconds * 1000);
}

export function cacheStats() {
  return db.prepare('SELECT COUNT(*) AS entries FROM cache WHERE expires_at >= ?').get(Date.now());
}
