import { config } from '../config.js';
import { cacheGet, cacheSet } from '../cache.js';
import { searchGenius, scrapeGeniusSong } from './genius.js';
import { searchLrclib, getLrclibLyrics } from './lrclib.js';
import { scoreMatch, normalizeText } from '../utils.js';

const ttl = config.cacheTtlSeconds;

function bestMatch(items, title, artist) {
  return [...items].map(item => ({
    ...item,
    _score: (scoreMatch(item.title, title) * 0.65) +
      (scoreMatch(item.artist, artist) * 0.35)
  })).sort((a, b) => b._score - a._score)[0] || null;
}

export async function searchSongs(query) {
  const key = `search:${normalizeText(query)}`;
  const cached = cacheGet(key);
  if (cached) return cached;

  const [geniusResult, lrclibResult] = await Promise.allSettled([
    searchGenius(query),
    searchLrclib(query)
  ]);

  const genius = geniusResult.status === 'fulfilled' ? geniusResult.value : [];
  const lrclib = lrclibResult.status === 'fulfilled' ? lrclibResult.value : [];

  const merged = new Map();
  for (const song of genius) {
    if (!song) continue;
    const id = song.id ? `genius:${song.id}` : `url:${song.genius_url}`;
    merged.set(id, { ...song, lyrics_sources: ['genius'] });
  }

  for (const song of lrclib) {
    const match = [...merged.values()].find(item =>
      scoreMatch(item.title, song.trackName) > 0.8 &&
      scoreMatch(item.artist, song.artistName) > 0.7
    );
    if (match) {
      match.lyrics_sources.push('lrclib');
      match.lrclib = {
        title: song.trackName,
        artist: song.artistName,
        album: song.albumName,
        duration: song.duration
      };
    } else {
      const id = `lrclib:${song.id}`;
      merged.set(id, {
        id: song.id,
        title: song.trackName,
        artist: song.artistName,
        album: song.albumName,
        genius_url: null,
        source: 'lrclib',
        lyrics_sources: ['lrclib']
      });
    }
  }

  const results = [...merged.values()].slice(0, config.maxSearchResults);
  const output = { query, count: results.length, results };
  cacheSet(key, output, ttl);
  return output;
}

export async function getSongLyrics({ title, artist, album, duration, geniusUrl }) {
  if (!title || !artist) throw new Error('Both title and artist are required.');

  const key = `lyrics:${normalizeText(title)}:${normalizeText(artist)}:${normalizeText(album || '')}`;
  const cached = cacheGet(key);
  if (cached) return cached;

  let geniusMatch = null;
  if (geniusUrl) {
    geniusMatch = { genius_url: geniusUrl, title, artist, album };
  } else {
    try {
      const hits = await searchGenius(`${title} ${artist}`);
      geniusMatch = bestMatch(hits, title, artist);
    } catch {
      // Lyrics providers below can still return a result if Genius is unavailable.
    }
  }

  let geniusPage = null;
  if (geniusMatch?.genius_url && process.env.GENIUS_SCRAPE_ENABLED !== 'false') {
    try {
      geniusPage = await scrapeGeniusSong(geniusMatch.genius_url);
    } catch {
      // A page can be unavailable; continue to LRCLIB.
    }
  }

  let lrclib = null;
  try {
    lrclib = await getLrclibLyrics({ title, artist, album, duration });
  } catch {
    // Keep a partial Genius result if LRCLIB is unavailable.
  }

  const plain = geniusPage?.plain || lrclib?.plain || null;
  const synced = lrclib?.synced || { type: 'line', available: false, lines: [] };
  const wordSynced = lrclib?.word_synced || { available: false, words: [] };

  const output = {
    success: Boolean(plain || synced.available || wordSynced.available),
    song: {
      title: geniusMatch?.title || lrclib?.title || title,
      artist: geniusMatch?.artist || lrclib?.artist || artist,
      album: geniusMatch?.album || lrclib?.album || album || null,
      release_date: geniusMatch?.release_date || null,
      genius_url: geniusMatch?.genius_url || null,
      duration: lrclib?.duration ?? duration ?? null
    },
    lyrics: {
      plain,
      synced,
      word_synced: wordSynced
    },
    availability: {
      plain: Boolean(plain),
      line_synced: Boolean(synced.available),
      word_synced: Boolean(wordSynced.available)
    },
    sources: {
      plain: geniusPage?.plain ? 'genius' : (lrclib?.plain ? 'lrclib' : null),
      synced: synced.available ? 'lrclib' : null,
      word_synced: wordSynced.available ? 'lrclib' : null
    }
  };

  cacheSet(key, output, ttl);
  return output;
}
