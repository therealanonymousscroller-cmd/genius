import { clientFor } from '../http.js';
import { parseLrc, normalizeWordSynced } from '../utils.js';

const api = clientFor('lrclib');
const BASE = 'https://lrclib.net/api';

export async function searchLrclib(query) {
  const { data } = await api.get(`${BASE}/search`, { params: { q: query } });
  return Array.isArray(data) ? data : [];
}

export async function getLrclibLyrics({ title, artist, album, duration }) {
  const params = { track_name: title, artist_name: artist };
  if (album) params.album_name = album;
  if (Number.isFinite(Number(duration)) && Number(duration) > 0) {
    params.duration = Math.round(Number(duration));
  }

  try {
    const { data } = await api.get(`${BASE}/get`, { params });
    return normalizeLrclib(data);
  } catch (error) {
    if (error.response?.status === 404) return null;
    throw error;
  }
}

export function normalizeLrclib(song) {
  if (!song) return null;
  const lineLyrics = song.syncedLyrics || '';
  const parsedLines = parseLrc(lineLyrics);
  const wordLines = normalizeWordSynced(song.lines);

  return {
    source: 'lrclib',
    title: song.trackName || null,
    artist: song.artistName || null,
    album: song.albumName || null,
    duration: song.duration ?? null,
    plain: song.plainLyrics || null,
    synced: parsedLines.length
      ? { type: 'line', available: true, lines: parsedLines }
      : { type: 'line', available: false, lines: [] },
    word_synced: wordLines
      ? { available: true, words: wordLines }
      : { available: false, words: [] }
  };
}
