import * as cheerio from 'cheerio';
import { clientFor } from '../http.js';
import { config } from '../config.js';

const api = clientFor('genius');
const web = clientFor('genius');
const API = 'https://api.genius.com';

function authHeaders() {
  return config.geniusToken
    ? { Authorization: `Bearer ${config.geniusToken}` }
    : {};
}

export async function searchGenius(query) {
  // Prefer Genius' official API when a token is configured.
  if (config.geniusToken) {
    try {
      const { data } = await api.get(`${API}/search`, {
        params: { q: query },
        headers: authHeaders()
      });
      return (data.response?.hits || []).map(hit => normalizeApiHit(hit.result));
    } catch (error) {
      // A configured API token may expire; continue to the permitted public search parser.
      if (!config.geniusScrapeEnabled) throw error;
    }
  }

  if (!config.geniusScrapeEnabled) {
    throw new Error('Genius search requires GENIUS_ACCESS_TOKEN or GENIUS_SCRAPE_ENABLED=true.');
  }

  const url = `https://genius.com/api/search/multi?${new URLSearchParams({
    q: query,
    per_page: String(config.geniusSearchPageSize)
  })}`;

  const { data } = await web.get(url, {
    headers: { Accept: 'application/json', Referer: 'https://genius.com/' }
  });

  const sections = data.response?.sections || [];
  const hits = sections.flatMap(section => section.hits || [])
    .filter(hit => hit.type === 'song' || hit.result?.url)
    .map(hit => normalizeApiHit(hit.result || hit));
  return hits;
}

function normalizeApiHit(song) {
  if (!song) return null;
  return {
    id: song.id ?? null,
    title: song.title || null,
    artist: song.primary_artist?.name || song.artist_names || null,
    album: song.album?.name || null,
    release_date: song.release_date_for_display || song.release_date || null,
    genius_url: song.url || null,
    page_views: song.stats?.pageviews ?? null,
    source: 'genius'
  };
}

export async function scrapeGeniusSong(url) {
  if (!config.geniusScrapeEnabled) {
    throw new Error('Genius page scraping is disabled.');
  }
  if (!/^https:\/\/(www\.)?genius\.com\//i.test(url)) {
    throw new Error('Only Genius song URLs can be scraped.');
  }

  const { data: html } = await web.get(url, {
    headers: { Referer: 'https://genius.com/' }
  });
  const $ = cheerio.load(html);

  const containers = $('[data-lyrics-container="true"]');
  let plain = null;
  if (containers.length) {
    plain = containers.map((_, el) => $(el).text().trim()).get()
      .filter(Boolean).join('\n\n');
  }

  // Page metadata is useful even if the lyrics container is not present.
  const title = $('meta[property="og:title"]').attr('content') || $('title').text() || null;
  const description = $('meta[property="og:description"]').attr('content') || null;
  const canonical = $('link[rel="canonical"]').attr('href') || url;

  return {
    title: title?.replace(/\s*\|\s*Genius.*$/i, '').trim() || null,
    description,
    genius_url: canonical,
    plain,
    lyrics_found: Boolean(plain)
  };
}
