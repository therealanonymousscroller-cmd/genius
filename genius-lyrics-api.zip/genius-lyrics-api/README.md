# Genius Lyrics API

A personal, proxy-aware song search and lyrics API. Genius is used for discovery and permitted page metadata/lyrics extraction; LRCLIB is used as a source for plain, line-synced, and word-synced lyrics when those formats are available.

## Requirements

- Node.js 20+
- npm
- Optional: Genius API access token
- Optional: HTTP(S) or SOCKS proxy

## Install

```bash
npm install
cp .env.example .env
npm start
```

Set `GENIUS_ACCESS_TOKEN` in `.env` for official Genius API search. The public Genius search parser is enabled by default when `GENIUS_SCRAPE_ENABLED=true`. Page parsing is also controlled by that setting. Only use scraping for content and access methods you are authorized to use; do not bypass login, bot checks, CAPTCHAs, or other access controls.

## Proxy configuration

One proxy for all providers:

```env
PROXY_URL=http://user:password@proxy.example:8080
```

Or separate proxies:

```env
GENIUS_PROXY_URL=http://user:password@proxy.example:8080
LRCLIB_PROXY_URL=socks5h://user:password@proxy.example:1080
```

Supported schemes: `http://`, `https://`, `socks4://`, `socks4a://`, `socks5://`, `socks5h://`.

Provider-specific proxy variables take precedence over `PROXY_URL`. Leave them empty to connect directly. Keep proxy credentials in `.env`, never commit that file, and use a proxy provider you are authorized to use. Proxy support is for network routing/privacy and does not circumvent service restrictions.

## Endpoints

### Health

```http
GET /health
```

### Search

```http
GET /search?q=Kendrick%20Lamar%20HUMBLE
```

Searches Genius and LRCLIB concurrently, merges likely matches, and returns metadata/source hints.

### Lyrics

```http
GET /lyrics?title=HUMBLE.&artist=Kendrick%20Lamar
```

Optional query parameters: `album`, `duration` (seconds), and `genius_url`.

Returns a stable JSON structure containing:
- `lyrics.plain`: full plain text if a source returns it.
- `lyrics.synced.lines`: line timestamps in seconds where LRCLIB has LRC data.
- `lyrics.word_synced.words`: word timestamps in seconds only when the source provides word-level timing.
- `availability` and `sources`: explicitly identify which formats exist and where each came from.

The service does not invent timestamps. Genius page text is not treated as synchronized lyrics. Word-level timing is only populated when the upstream source supplies word timing.

### Direct permitted Genius page parse

```bash
curl -X POST http://localhost:3000/scrape \
  -H "Content-Type: application/json" \
  -d '{"url":"https://genius.com/ARTIST-SONG-lyrics"}'
```

Only Genius URLs are accepted by this endpoint.

## Notes / limitations

- Genius' official API search requires an access token and does not provide full lyrics. The optional HTML parser reads the page's `data-lyrics-container` elements when present and accessible.
- Genius page markup can change. If Genius changes its HTML or returns a consent/verification page, the parser may return metadata without lyrics. It does not attempt to evade access controls.
- LRCLIB coverage varies by song. Not every track has plain, line-synced, or word-synced lyrics.
- `success` means at least one lyrics format was found, not that all formats were available.
- SQLite cache is stored at `data/cache.sqlite`.
- Search results are best-effort merged; verify title and artist before relying on a match.

## Example response

```json
{
  "success": true,
  "song": {
    "title": "Example Song",
    "artist": "Example Artist",
    "album": null,
    "release_date": null,
    "genius_url": "https://genius.com/..."
  },
  "lyrics": {
    "plain": "Lyrics text...",
    "synced": {
      "type": "line",
      "available": true,
      "lines": [{ "time": 12.5, "text": "A lyric line" }]
    },
    "word_synced": {
      "available": false,
      "words": []
    }
  },
  "availability": {
    "plain": true,
    "line_synced": true,
    "word_synced": false
  },
  "sources": {
    "plain": "genius",
    "synced": "lrclib",
    "word_synced": null
  }
}
```
